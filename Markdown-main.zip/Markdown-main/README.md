# Markdown

* Atividade Q13 Analise E Projeto de Sistemas

Este é o repositório do projeto que está sendo desenvolvido nas aulas da disciplina de Front-End. O objetivo deste projeto é criar uma página web usando HTML, CSS e JavaScript, que ofereça diversas funcionalidades e seja responsiva.

## Desenvolvedor

* Desenvolvido por: *Murilo*

## Turma

* 2º Ano B Manha - Médio Integrado

## Funcionalidades

Aqui estão algumas das principais funcionalidades que o site terá:

- Responsividade para funcionar bem em dispositivos móveis e desktop.
- Uma barra de navegação intuitiva com links para diferentes partes do site.
- Um botão que permite ao usuário alterar a cor do fundo da página, podendo alterar do modo escuro para o modo claro.

Fique à vontade para acompanhar nosso progresso neste repositório e contribuir com ideias ou sugestões.
